//
//  ViewController.swift
//  SilverPaper
//
//  Created by sugyan5243 on 2017/10/29.
//  Copyright © 2017年 sugyan5243. All rights reserved.
//
//  メインのView．鶴田のプログラムを参考に微調整
//  以下，鶴田の解説

// シリアル通信が有効な状態だと非常にメモリとCPUと電源リソースを食う．(使う分には全然使えるが)
// 個別に調べた結果，GLによるレンダリングや，serialPort:didReceivePacket:matchingDescriptor: メソッドでの中身は，
// 動作の重さに影響を与えていなかった．また，ディスクリプタを用いたパケット切り出しも悪影響ではなかった．
// 単に，これくらいの高頻度でORSSerialPortを使うと重い，という感じのようである．(つまりORSSerialPort側でのリソースコントロールが上手くいっていない？)


import Cocoa
import ORSSerial

class ViewController: NSViewController, ORSSerialPortDelegate {
    
    
    // メンバ変数を宣言するだけで初期化を行わない際は暗黙的にnilが挿入されるようだが、swiftでは普通の変数(var)や定数(let)にnilを入れることはできない。
    // そのため、宣言だけしたいときは、オプショナル型にする。サフィックスが ! ならnilが入ったときにエラーとし、? ならnilをそのまま入れる
    
    //--------------
    // シリアルポート
    //--------------
    
    // シリアルポートの一覧
    var _serialPorts : [ORSSerialPort] = [] // swiftのArray型の指定方法は[]で囲むことに注意
    var _serialPortNames : [String] = []
    // 使用するシリアルポート
    var _selectedSerialPort : ORSSerialPort? {
        didSet {
            oldValue?.close()
            oldValue?.delegate = nil
            _selectedSerialPort?.delegate = self // 必ずデリゲートを自分に設定する(たまによく忘れて嵌まる…)
        }
    }
    var _selectedSerialPortTag : NSNumber? // プルダウンで選ばれたシリアルポートのタグを保持
    @IBOutlet weak var _selectedSerialPortLabel : NSTextField? // 選択されたシリアルポートの表示用ラベル
    
    //--------
    // OpenGL
    //--------
    
    // センサ値を描画するNSOpenGLView
    @IBOutlet weak var _openglView : NSOpenGLView?
    // 描画処理を記述するクラスを切り分ける
    var _openGLContents : OpenGLContentsDraw?
    
    //------------
    // センサ値関連
    //------------
    
    // センサモデルクラス (シングルトン) 明示的にイニシャライズする必要は無い (シングルトンはランタイムが起動してくれた時点でシェアードになる)
    //var sensor : Sensor = Sensor.init()
    
    // センサ値の数値表示用
    //var _sensorValue : Int = 0 // 専用のシングルトンのモデルクラスを作成した．Sensor.sharedInstance でアクセスできる
    @IBOutlet weak var _sensorValueLabel : NSTextField?
    
    // ローパス用
    var isLowpassEnabled : Bool = true // ローパス有効・無効
    dynamic var lowpassRatio : Float = 0.99 // ローパスの重み 0.99
    var lowpassedValue : Float = 0.0 // ローパス値
    var oldVal : Float = 0.0 // ローパス用の履歴値
    
    // ピークホールド用
    var isPeakHoldEnabled : Bool = false // ピークホールド有効・無効
    var peakHoldedValue : Float = 65535.0 // ピークホールド値
    let descendingValue : Float = 1 // ピークを徐々に下げていく際に1回どれくらい下げるか．波形のガタつきより十分小さくする．大きいと逆にガタつく
    
    // 計算過程で更新されて最終的に使用する値
    var processedValue : Float = 0.0
    
    
    /*===============================================================================================================================================================================================================*/
    // 初期化関連
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //ORSSerialPort *port = [ORSSerialPort serialPortWithPath:@"/dev/cu.KeySerial1"];
        
        // シリアルポートオブジェクトの一覧を取得して、その名前の配列を別に作る
        _serialPorts = ORSSerialPortManager.shared().availablePorts
        for serialPort : ORSSerialPort in _serialPorts {
            _serialPortNames.append(serialPort.path)
        }
    }
    
    override func viewDidAppear() {
        // シリアルポート選択シートを表示する．
        // viewDidLoadではまだviewのヒエラルキーが確立されていないため、こちらで呼び出す必要がある
        performSegue(withIdentifier: "SerialPortSelectPresent", sender: self)
        // 新しいviewControllerをコードで生成している場合は以下などでセグエできる
        //presentViewControllerAsModalWindow()
        
        // 可視化のためのOpenGLビューを作成して登録
        _openGLContents = OpenGLContentsDraw(frame: CGRect(x: 0,y: 0,width: _openglView!.bounds.width,height: _openglView!.bounds.height), PointSize: GLfloat(20.0))
        _openglView!.addSubview(_openGLContents!)
    }
    
    override func viewDidDisappear() {
        //removeObserver(self, forKeyPath: "_selectedSerialPortTag")
    }
    
    override func mouseDown(with theEvent: NSEvent) {
        //_openGLContents!.updateScene()
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // KVOした値が変化したらこれが叩かれる
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        // シリアルポートの選択が行われたら
        if keyPath == "_selectedSerialPortTag" {
            
            //-------------------
            // シリアルポートの設定
            //-------------------
            
            // 新しく選ばれたアイテムのタグを取得
            _selectedSerialPortTag = change![NSKeyValueChangeKey.newKey] as? NSNumber
            // タグをもとにORSSerialPortインスタンスを取得
            _selectedSerialPort = _serialPorts[_selectedSerialPortTag as! Int]
            // ボーレートを設定
            //_selectedSerialPort?.allowsNonStandardBaudRates = true // これをtrueにすると961200などでもエラー吐かなくなるが，動かなかった
            _selectedSerialPort?.baudRate = 230400; // 230400, 961200
            //_selectedSerialPort?.numberOfStopBits = 1;
            //_selectedSerialPort?.usesRTSCTSFlowControl = true;
            // シリアルポートをオープン
            _selectedSerialPort?.open()
            
            // ラベルにシリアルポート名を表示
            _selectedSerialPortLabel!.stringValue = _selectedSerialPort!.path
        }
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // OSORSSerialPortのデリゲートメソッド群 (必須はserialPortWasRemovedFromSystemのみ)
    
    //------------
    // コネクション
    //------------
    
    // シリアルポートに対してopen()が叩かれてコネクションが開いた際に呼ばれる
    func serialPortWasOpened(_ serialPort: ORSSerialPort) {
        print("Serial port was opend.")
        
        // どのような形の文字列をパケットとみなして受け取るか (ディスクリプタ/検索記述) の設定を行う
        let descriptor = ORSSerialPacketDescriptor(prefixString: "!pos", suffixString: ";", maximumPacketLength: 16, userInfo: nil)
        // シリアルポートのリスニングを開始 (ディスクリプタを利用)
        _selectedSerialPort!.startListeningForPackets(matching: descriptor)
        print("Start listening.")
    }
    
    // シリアルポートに対してclose()が叩かれてコネクションが閉じた際に呼ばれる
    func serialPortWasClosed(_ serialPort: ORSSerialPort) {
        print("Serial port was closed.")
    }
    
    // USBが抜かれたなどの理由でシステムからポートが見えなくなった場合に呼ばれる。この場合は参照していたシリアルポートはここで破棄すること
     func serialPortWasRemovedFromSystem(_ serialPort: ORSSerialPort) {
        //    func serialPortWasRemoved(fromSystem serialPort: ORSSerialPort) {
        print("Serial port was removed from system.")
        
        // シリアルポートの破棄
        _selectedSerialPort = nil
    }
    
    //------------
    // データの取得
    //------------
    
    // 1ビット(1バイトか？)などとにかくデータを1文字でも受け取ったらそのたびに呼ばれる。
    // データの取得はバックグラウンドキューで行われる(データ取得でメイン処理をブロックしないため)が、このメソッドの呼び出しはメインキューで呼ばれる。
    // これだけを用いた場合、手作業でデータをチャンク(パケット)ごとに分ける作業をしなければならないので面倒だが、代わりにPacketDescriptorを使うことで簡単にパケットごとにデータを取得できる
    //func serialPort(serialPort: ORSSerialPort, didReceiveData data: NSData) {
    //
    //}
    
    // 指定していた形でパケットとしてデータが収集できた際に呼ばれる
    func serialPort(_ serialPort: ORSSerialPort, didReceivePacket packetData: Data, matching descriptor: ORSSerialPacketDescriptor) {
        // NSData型を文字列型に変換してパケットを取得
        var string = String.init(data: packetData, encoding: String.Encoding.utf8)
        
        // stringがnilでなければ以降が実行．
        // stringがnilならばセンサ値が0であるとみなすための処理を行う
        if let _ = string {
            // パケットからプリフィクス・サフィックスを削除して値を抽出
            string = string?.substring(with: string!.characters.index(string!.startIndex, offsetBy: 4)..<string!.characters.index(string!.endIndex, offsetBy: -1))
            // パケットから文字列で得た値を数値に変換
            let val : Float = Float(string!)!
            
            // ローパスが有効なら
            if isLowpassEnabled {
                lowpassedValue = val*(1.0-lowpassRatio) + oldVal*lowpassRatio
                processedValue = lowpassedValue
            } else {
                processedValue = val
            }
            oldVal = processedValue
            
            // ピークホールドが有効なら
            if isPeakHoldEnabled {
                // リアルタイムなセンサ値が現在のピークホールド値を小突くようなら，ピークホールド値を更新
                if processedValue < peakHoldedValue {
                    peakHoldedValue = processedValue
                    // リアルタイムセンサ値が現在のピークホールド値を超えないなら，ピークホールド値をゆっくり下げる
                    // (今回の場合は上下反転しているので上げる)
                } else {
                    peakHoldedValue = peakHoldedValue + descendingValue
                }
                // 処理済み値に保存
                processedValue = peakHoldedValue
                // ふたたびピークホールドが有効になったときのために最新の値を入れておく
            } else {
                peakHoldedValue = processedValue
            }
            
            // 最終的に使用する値 (整数に変換)
            let finalValue : Int = Int(processedValue)
            
            // Sensorモデルクラスに書込
            // 送り先がIntなので，小数点以下を捨てていることに注意
            Sensor.sharedInstance.sensorValue = finalValue
            
            // ふたたび文字列に変換
            let stringFinalVal : String = String(finalValue)
            
            // ラベルに値を表示
            //_sensorValueLabel?.stringValue = string!
            _sensorValueLabel?.stringValue = stringFinalVal
            
            // openGLViewに値を渡す
            // べつに文字列で渡す必要性はないので，のちのち数値渡しにする
            //_openGLContents?._valueString = string!
            _openGLContents?._valueString = stringFinalVal
            // openGLViewを更新
            _openGLContents!.updateScene()
            
            // 破棄
            string = nil
        } else {
            Sensor.sharedInstance.sensorValue = 0
            _sensorValueLabel?.stringValue = "0"
            _openGLContents?._valueString = "0"
            _openGLContents!.updateScene()
        }
    }
    
    // 指定していたリクエストに対してレスポンスとなるデータが得られた際に呼ばれる
    func serialPort(_ serialPort: ORSSerialPort, didReceiveResponse responseData: Data, to request: ORSSerialRequest) {
        
    }
    
    //-------
    // その他
    //-------
    
    func serialPort(_ serialPort: ORSSerialPort, requestDidTimeout request: ORSSerialRequest) {
        print("Request did timeout.")
    }
    
    func serialPort(_ serialPort: ORSSerialPort, didEncounterError error: NSError) {
        print("Did encounter error", error)
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // アクションメソッド群
    
    // シリアルポートの再選択を行うためにシートを表示
    @IBAction func selectSerialPortButtonClicked(_ sender: AnyObject) {
        performSegue(withIdentifier: "SerialPortSelectPresent", sender: self)
    }
    
    // ローパスの有効・無効
    @IBAction func lowpassCheckboxClicked(_ sender : AnyObject) {
        let state : Int = (sender as! NSButton).state
        switch state {
        case NSOnState:
            isLowpassEnabled = true
            break
        case NSOffState:
            isLowpassEnabled = false
            break
        default:
            break
        }
    }
    
    // ピークホールドの有効・無効
    @IBAction func peakHoldCheckboxClicked(_ sender : AnyObject) {
        let state : Int = (sender as! NSButton).state
        switch state {
        case NSOnState:
            isPeakHoldEnabled = true
            break
        case NSOffState:
            isPeakHoldEnabled = false
            break
        default:
            break
        }
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // セグエ先のviewControllerに情報を渡す
    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
        if segue.identifier == "SerialPortSelectPresent" {
            // セグエ先のviewControllerを取得
            let serialPortSelectViewController = segue.destinationController as! SerialPortSelectViewController
            // セグエ先のviewControllerのプロパティに対してKVO(キー値監視)する
            serialPortSelectViewController.addObserver(self, forKeyPath: "_selectedSerialPortTag", options: .new, context: nil)
            // セグエ先にrepresentedObjectを介してシリアルポート名の一覧を渡す
            serialPortSelectViewController.representedObject = _serialPortNames
        }
    }
    
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
}

