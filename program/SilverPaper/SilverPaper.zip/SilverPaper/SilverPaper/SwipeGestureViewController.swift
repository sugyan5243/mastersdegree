//
//  SwipeGestureViewController.swift
//  capCalc
//
//  Created by mtfrctl on 2016/07/02.
//  Copyright © 2016年 鶴田 真也. All rights reserved.
//

import Cocoa

class SwipeGestureViewController: NSViewController {
    
    @IBOutlet weak var swipeUp : NSButton?
    @IBOutlet weak var swipeDown : NSButton?
    @IBOutlet weak var swipeLeft : NSButton?
    @IBOutlet weak var swipeRight : NSButton?
    
    // タッチ状態を表示するラベル
    @IBOutlet weak var touchingStateLabel : NSTextField?
    // ジェスチャ状態を表示するラベル
    @IBOutlet weak var gesturingStateLabel : NSTextField?
    
    fileprivate
    
    // リアルタイムなセンサ値をSensorモデルクラスから取ってきて保持する用
    var sensorValue : Int = 0
    // 最大のセンサ値
    let sensorMaxValue : Int = 65535
    
    // 最初センサ値が安定するまで待つためのカウンタ
    let startWaitNumber : Int = 1000
    var startWaitCounter : Int = 0
    
    // テストカウンタ (センサ値が閾値を下回った回数をカウント．開発試験用)
    var testCounter : Int = 0
    
    // ジェスチャとみなされるのに必要なタッチ回数
    let touchNumberForGesture : Int = 2
    // ジェスチャにおけるタッチカウンタ
    var touchCounterForGesture : Int = 0
    
    // ジェスチャにおけるピーク値
    var notchPeaks : [Int] = [Int](repeating: 65535, count: 2)
    
    
    /*===============================================================================================================================================================================================================*/
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
        print("SwipeGestureView startup")
        
        // ジェスチャのタッチカウンタを初期化
        touchCounterForGesture = touchNumberForGesture
        // 開始時のウェイトカウンタを初期化
        startWaitCounter = startWaitNumber
    }
    
    override func viewWillAppear() {
        print("SwipeGestureView appear")
        Sensor.sharedInstance.addObserver(self, forKeyPath: "sensorValue", options: .new, context: nil)
    }
    
    override func viewDidDisappear() {
        Sensor.sharedInstance.removeObserver(self, forKeyPath: "sensorValue")
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // 監視しているキー値が変更されるたび実行
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        // センサ値が更新されたら
        if keyPath == "sensorValue" {
            // センサ値を取得し，本クラスのインスタンス変数に保存
            sensorValue = change![NSKeyValueChangeKey.newKey] as! Int
            
            // センサ値が安定するまで暫く待つ
            startWaitCounter -= 1
            if startWaitCounter < 0 {
                
                // センサ値が閾値を下回ったらジェスチャ電極をタッチしたとみなす
                if sensorValue < 65000 {
                    //testCounter += 1
                    //print(testCounter)
                    
                    // はじめの1回だけ
                    if Enums.sharedInstance.swipeGestureTouchingState == .swipeGestureTouchingStateNotTouching {
                        Enums.sharedInstance.swipeGestureTouchingState = .swipeGestureTouchingStateTouching
                        touchingStateLabel?.stringValue = "Touching."
                        // ジェスチャのタッチカウンタをデクリメント
                        touchCounterForGesture -= 1
                        // ジェスチャステートを設定 (ジェスチャ中)
                        if touchCounterForGesture > 0 {
                            Enums.sharedInstance.swipeGestureGesturingState = .swipeGestureGesturingStateGesturing
                            gesturingStateLabel?.stringValue = "Gesturing."
                            
                            // ピーク値をリセット
                            notchPeaks[0] = 65535
                            notchPeaks[1] = 65535
                        }
                    }
                }
                    // センサ値が閾値を上回ったらタッチ終了とみなす
                else if 65000 <= sensorValue {
                    // はじめの1回だけ
                    if Enums.sharedInstance.swipeGestureTouchingState == .swipeGestureTouchingStateTouching {
                        Enums.sharedInstance.swipeGestureTouchingState = .swipeGestureTouchingStateNotTouching
                        touchingStateLabel?.stringValue = "Not touching."
                        // ジェスチャステートを設定 (ジェスチャ中でない)
                        if touchCounterForGesture <= 0 {
                            Enums.sharedInstance.swipeGestureGesturingState = .swipeGestureGesturingStateNotGesturing
                            gesturingStateLabel?.stringValue = "Not gesturing."
                            // ジェスチャのタッチカウンタを初期化
                            touchCounterForGesture = touchNumberForGesture
                            
                            // ジェスチャのピーク値をログ
                            print("touch1: ", notchPeaks[1])
                            print("touch2: ", notchPeaks[0], " Touch end.")
                            
                            // 判定を表示
                            highlightKey()
                        }
                    }
                }
                
                // ジェスチャ中か否か
                switch Enums.sharedInstance.swipeGestureGesturingState {
                case .swipeGestureGesturingStateGesturing:
                    // 下端ピーク値を更新
                    if sensorValue < notchPeaks[touchCounterForGesture] {
                        notchPeaks[touchCounterForGesture] = sensorValue
                    }
                    break
                case .swipeGestureGesturingStateNotGesturing:
                    break
                }
            }
        }
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // キーをハイライト
    // 現在のセンサ値を各キーの上下閾値と比較する
    func highlightKey() {
        let val = notchPeaks[1] - notchPeaks[0]
        print("diff: ", val)
        
        if val < -17000 {
            print("----up----")
            swipeUp?.state = NSOnState // ON
            swipeDown?.state = NSOffState
            swipeLeft?.state = NSOffState
            swipeRight?.state = NSOffState
        }
        else if 18000 < val {
            print("----down----")
            swipeUp?.state = NSOffState
            swipeDown?.state = NSOnState // ON
            swipeLeft?.state = NSOffState
            swipeRight?.state = NSOffState
        }
        else if -17000 < val && val < -5000 {
            print("----left----")
            swipeUp?.state = NSOffState
            swipeDown?.state = NSOffState
            swipeLeft?.state = NSOnState // ON
            swipeRight?.state = NSOffState
        }
        else if 5000 < val && val < 18000 {
            print("----right----")
            swipeUp?.state = NSOffState
            swipeDown?.state = NSOffState
            swipeLeft?.state = NSOffState
            swipeRight?.state = NSOnState // ON
        }
        
        
        // 18000より小さかったらタップ (印刷面全体を手で覆う)
        
        // ±5000の範囲ならダブルタップ
    }
}

