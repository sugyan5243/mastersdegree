//
//  MFHoldableButton.swift
//  capCalc
//
//  Created by mtfrctl on 2016/06/14.
//  Copyright © 2016年 鶴田 真也. All rights reserved.
//

// 押され続けていることを検知し，これを一定間隔で通知センターにポストするように拡張したボタン
// → 押され続けている間に一定間隔で通知を出すのは今回の用途では不都合があったため，結局押し始めたときと離したときのみを送り，送り先でこれらから押している間を判断するようにした．
// このボタンを利用する側のクラスでは，ボタンへの参照を持っている必要は必ずしもないが，
// 通知センターに対して "buttonHolding" 通知を監視しておくのと，それに呼応する処理の実装を行う必要がある．

import Cocoa

class MFHoldableButton: NSButton {
    
    // 通知
    var buttonDownNotification : Notification?
    var buttonHoldingNotification : Notification?
    var buttonUpNotification : Notification?
    // タイマー (作成と解除を別スコープで行いたいため，インスタンス変数としてシェアしている)
    var timer : Timer?
    // タイマー間隔
    let interval : TimeInterval = 0.05
    
    
    /*===============================================================================================================================================================================================================*/
    // 初期化メソッド．元々は書かれていない．NSViewのinitをoverrideするかたちとなる．
    
    // コードから生成する場合はこちら
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
    }
    
    // Storuboardから作られるので今回はこちら
    required init?(coder: NSCoder) {
        //fatalError("init(coder:) has not been implemented")
        super.init(coder: coder)
        
        //Swift.print("button initialized")
        
        // 通知を作成
        //buttonDownNotification = NSNotification(name: "buttonDown", object: self, userInfo: nil)
        //buttonHoldingNotification = NSNotification(name: "buttonHolding", object: self, userInfo: nil)
        //buttonUpNotification = NSNotification(name: "buttonUp", object: self, userInfo: nil)
        
        // タイマーを作成 → こちらでは作成しない．タイマー解除の度にタイマーも開放されるので，都度新しくタイマーを作ってやる必要がある．
        //timer = NSTimer(timeInterval: 0.1, target: self, selector: #selector(self.postHoldingNotification(_:)), userInfo: nil, repeats: true)
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // (本ボタン内で)マウスダウンが起こったとき
    override func mouseDown(with theEvent: NSEvent) {
        Swift.print("mouse down in button", self.tag)
        
        let buttonDownNotification = Notification(name: Notification.Name(rawValue: "buttonDown"), object: self, userInfo: nil)
        // ボタンダウンタイミングの通知をポスト
        NotificationCenter.default.post(buttonDownNotification)
        
        //        // タイマーを作成
        //        timer = NSTimer(timeInterval: interval, target: self, selector: #selector(self.postHoldingNotification(_:)), userInfo: nil, repeats: true)
        //        //正しくタイマーが作成されていれば
        //        if let timer = timer {
        //            // タイマーをランループに登録 (スケジュール)．これでタイマーが自動で発火するようになる
        //            NSRunLoop.currentRunLoop().addTimer(timer, forMode: NSDefaultRunLoopMode)
        //        }
    }
    
    //    // 通知をポストするためだけのメソッド．NSTimerの引数に渡すために便宜的に設けている
    //    func postHoldingNotification(timer: NSTimer) {
    //        // ボタンホールディング中の通知をポスト
    //        NSNotificationCenter.defaultCenter().postNotification(buttonHoldingNotification!)
    //    }
    
    // (本ボタン内で)マウスアップが起こったとき
    override func mouseUp(with theEvent: NSEvent) {
        Swift.print("mouse up in/outof button", self.tag)
        
        let buttonUpNotification = Notification(name: Notification.Name(rawValue: "buttonUp"), object: self, userInfo: nil)
        // ボタンアップタイミングの通知をポスト
        NotificationCenter.default.post(buttonUpNotification)
        
        // タイマーを解除 (ランループから登録解除するだけでなく，タイマー自体も開放されるらしい)
        //        timer?.invalidate()
    }
    
    
    /*===============================================================================================================================================================================================================*/
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        
        // Drawing code here.
    }
}

