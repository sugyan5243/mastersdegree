//
//  Sensor.swift
//  SilverPaper
//
//  Created by sugyan5243 on 2017/10/29.
//  Copyright © 2017年 sugyan5243. All rights reserved.
//
// センサ値を表すモデルクラス．シングルトンで共有される．鶴田のプログラムをそのまま用いている

import Cocoa

class Sensor: NSObject {
    
    // 1.2より前のシングルトンの書き方
    //    class var sharedInstance: Sensor {
    //        struct Singleton {
    //            static let instance: Sensor = Sensor()
    //        }
    //        return Singleton.instance
    //    }
    
    // 1.2以降はこれでよい
    static let sharedInstance = Sensor()
    
    // 最初，initメソッドは設けていなかった．明示的にinitを作ってこれを明示的に叩くようにすると，2回initが呼ばれることがわかった．
    // おそらく，シェアードなクラス (シングルトン) の場合，ランタイム側で勝手にinit()を叩いてくれるからと思われる．
    // シングルトンなので2回叩かれても実害はないが，明示的に叩く意味は無い．
    // シングルトンでも，init自体を明示的に再定義すること自体は普通にやってよい．
    override init() {
        super.init()
        print("Sensor model initialized!!")
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // センサ値
    dynamic var sensorValue : Int = 0 {
        didSet {
            // バッファを更新
            sensorValueBuffer.append(sensorValue)
            sensorValueBuffer.removeFirst()
        }
    }
    // センサ値バッファ (過去10回分のセンサ値を保持)
    var sensorValueBuffer : [Int] = [Int](repeating: 0, count: 100)
}

