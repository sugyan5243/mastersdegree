//
//  SilverPaperViewController.swift
//  SilverPaper
//
//  Created by sugyan5243 on 2017/10/29.
//  Copyright © 2017年 sugyan5243. All rights reserved.
//

import Cocoa

class SilverPaperViewController: NSViewController {
    
    @IBOutlet weak var swipeUp : NSButton?
    @IBOutlet weak var swipeDown : NSButton?
    @IBOutlet weak var swipeLeft : NSButton?
    @IBOutlet weak var swipeRight : NSButton?
    
    // センサ値を表示するラベル
    @IBOutlet weak var sensorOriginValueLabel : NSTextField?
    // ジェスチャ結果を表示するラベル
    @IBOutlet weak var gesturingStateLabel : NSTextField?
    
    //実験回数表示
    @IBOutlet var Algorithm1 : NSButton!
    @IBOutlet weak var debugLabel : NSTextField?
    @IBOutlet weak var debugLabel2 : NSTextField?
    
    fileprivate
    
    var test : Int = 0
    

    //基本データ
    var startMe : Int = 0   //実験開始
    var taiki : Int = 0 //count回データを保持するまで待機
    var sensorValue : Int = 0   //リアルタイム更新
    var sensordatas : [Int] = [Int](repeating: 65535, count: 100)   //過去count回のデータ保持
    var sensorAverage : Double = 0  //過去count回の平均値
    var maxs : Int = 100
    var testtime : String = ""
    
    //Algorithm 1:閾値
    var checkmode : Int = 0    //0:未開始 1:閾値1超えた 2:閾値2超えた
    let sikii1 : Int = 27000
    let sikii2 : Int = 30000
    
    //Algorithm 2:最大値
    var timecount : Int = 0
    var sensorMinValue : Double = 65535
    var sensorMaxValue : Double = 0
    var maxcount : Int = 0
    var sensorMaxs : [Double] = [Double](repeating: 65535, count: 100)
    
    /*===============================================================================================================================================================================================================*/
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
        print("SilverPaperView startup")
        //ファイル作成して準備
        createAndWriteTextFile(textFileName: "test.txt");
    }
    
    override func viewWillAppear() {
        print("SilverPaperView appear")
        //監視対象にsensorValue(Sensorモデルクラスのやつ)を追加
        Sensor.sharedInstance.addObserver(self, forKeyPath: "sensorValue", options: .new, context: nil)
        //時間出すよ
        anstime()
    }
    
    override func viewDidDisappear() {
        Sensor.sharedInstance.removeObserver(self, forKeyPath: "sensorValue")
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // 監視しているキー値が変更されるたび実行
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        // センサ値が更新されたら
        if keyPath == "sensorValue" {
            
            // センサ値を取得し，本クラスのインスタンス変数に保存
            sensorValue = change![NSKeyValueChangeKey.newKey] as! Int
            
            if(Algorithm1?.state == NSOnState){
                test += 1
                if(test % 5 == 0){
                appendText(fileURL: FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).last!, string: sensorValue.description,textFileName: "test.txt");
                    test = 0
                }
            }
            
            if(taiki > 100){
                //配列の更新・最小値の更新と平均値の取得を行う
                sensorAverage = 0
                for i in 0..<maxs-1 {
                    sensordatas[i] = sensordatas[i+1]
                    sensorAverage += Double(sensordatas[i])
                }
                sensordatas[maxs-1] = sensorValue
                sensorAverage += Double(sensordatas[9])
                sensorAverage /= Double(maxs)
                sensorOriginValueLabel?.doubleValue = sensorAverage
                
                //Algorithm 1:閾値
                if(Algorithm1?.state == NSOnState){
                    if(sensorAverage > Double(sikii1) && checkmode == 0){
                        checkmode = 1
                    }
                    if(sensorAverage > Double(sikii2)){
                        checkmode = 2
                    }
                    
                    if(sensorAverage < Double(sikii1) && checkmode != 0){
                        gesturingStateLabel?.stringValue += String(checkmode-1)
                        checkmode = 0
                    }
                
                //Algorithm 2:最大値
                }else if(Algorithm1?.state == NSOffState && startMe == 1){
                    
                    //ステップ1:閾値を超えたら開始
                    if(sensorAverage > Double(sikii1)){
                        checkmode = 1
                        if(sensorMaxs[maxcount] < sensorAverage){
                            sensorMaxs[maxcount] = sensorAverage
                        }
                        //最大値の更新
                        if(sensorMaxValue < sensorMaxs[maxcount]){
                            sensorMaxValue = sensorMaxs[maxcount]
                        }
                    }
                    
                    //ステップ2:閾値を下回ったら一旦終わり
                    if(sensorAverage < Double(sikii1) && checkmode == 1){
                        maxcount += 1
                        checkmode = 2
                        //最小値の更新
                        if(sensorMinValue > sensorMaxs[maxcount]){
                            sensorMinValue = sensorMaxs[maxcount]
                        }
                    }
                    
                    //時間経過で終了と認識
                    if(checkmode == 2){
                        timecount += 1
                        if(timecount > 2000){
                            checkmode = 0
                            //画面に結果表示
                            for i in 0..<maxcount {
                                //最大と最小のどちらに近いかで分類
                                if((sensorMaxValue-sensorMaxs[i]) > (sensorMaxs[i]-sensorMinValue)){
                                    gesturingStateLabel?.stringValue += "0"
                                }else if((sensorMaxValue-sensorMaxs[i]) < (sensorMaxs[i]-sensorMinValue)){
                                    gesturingStateLabel?.stringValue += "1"
                                }
                            }
                            print(gesturingStateLabel?.stringValue)
                            print(maxcount)
                            print(sensorMaxValue)
                            print(sensorMinValue)
                            maxcount = 0
                            sensorMaxValue = 0
                            sensorMinValue = 65535
                        }
                    }
                }
            }else{
                taiki += 1
            }
        }
    }
    
    func anstime(){
        let formatter = DateFormatter()
        formatter.dateFormat = "HHmmss"
        var nowTime = formatter.string(from: Date())
        testtime = nowTime
        print(nowTime)
    }
    
    func createAndWriteTextFile(textFileName:String) {
        // 作成するテキストファイルの名前
        let initialText = "最初に書き込むテキスト"
        // DocumentディレクトリのfileURLを取得
        if let documentDirectoryFileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).last {
            // ディレクトリのパスにファイル名をつなげてファイルのフルパスを作る
            let targetTextFilePath = documentDirectoryFileURL.appendingPathComponent(textFileName)
            print("書き込むファイルのパス: \(targetTextFilePath)")
            do {
                try initialText.write(to: targetTextFilePath, atomically: true, encoding: String.Encoding.utf8)
            } catch let error as NSError {
                print("failed to write: \(error)")
            }
        }
    }
    
    // テキストを追記するメソッド
    func appendText(fileURL: URL, string: String, textFileName: String) {
        do {
            let fileHandle = try FileHandle(forWritingTo: fileURL.appendingPathComponent(textFileName))
            // 改行を入れる
            let stringToWrite = "\n" + string
            // ファイルの最後に追記
            fileHandle.seekToEndOfFile()
            fileHandle.write(stringToWrite.data(using: String.Encoding.utf8)!)
        } catch let error as NSError {
            print("failed to append: \(error)")
        }
    }
    
    //ボタンが押された時用
    @IBAction func buttonTapped(_ sender : Any) {
        if(Algorithm1?.state == NSOnState){
            startMe = 1
            debugLabel?.stringValue = "Algorithm 1";
            debugLabel2?.integerValue = (debugLabel2?.integerValue)! + 1;
        }else{
            debugLabel?.stringValue = "Algorithm 2";
        }
    }
}

