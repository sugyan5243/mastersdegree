//
//  OpenGLContentsDraw.swift
//  SilverPaper
//
//  Created by sugyan5243 on 2017/10/29.
//  Copyright © 2017年 sugyan5243. All rights reserved.
//
//  OpenGLによるセンサ値の描画．鶴田のプログラムをそのまま用いている

import Foundation
import Cocoa
import OpenGL
import GLKit
import GLUT

class OpenGLContentsDraw: NSOpenGLView {
    
    var _width:GLsizei
    var _height:GLsizei
    
    // センサ値格納用
    var _valueString : String = ""
    // 描画用センサ値配列
    var _array : [Int] = []
    // 描画時に画面を何分割するか (要するにbin数)
    let _devideNumber : Int = 1024
    
    
    /*===============================================================================================================================================================================================================*/
    // 初期化
    init?(frame:NSRect, PointSize:GLfloat) {
        
        //----------
        // OpenGL用
        //----------
        
        //set size of this view
        _width = GLsizei(frame.size.width)
        _height = GLsizei(frame.size.height)
        
        //setup pixelFormatAttributes
        let pixelFormatAttributes:[NSOpenGLPixelFormatAttribute] = [
            UInt32(NSOpenGLPFAAccelerated),
            UInt32(NSOpenGLPFADoubleBuffer),
            UInt32(NSOpenGLPFADepthSize), UInt32(32),
            UInt32(NSOpenGLPFAColorSize), UInt32(48),
            UInt32(NSOpenGLPFAAlphaSize), UInt32(16),
            UInt32(NSOpenGLPFAMultisample),
            UInt32(NSOpenGLPFASampleBuffers), UInt32(1),
            UInt32(NSOpenGLPFASamples), UInt32(4),
            UInt32(NSOpenGLPFAMinimumPolicy),
            UInt32(0)
        ]
        
        let glPixelFormat = NSOpenGLPixelFormat(attributes:pixelFormatAttributes)
        super.init(frame:frame, pixelFormat:glPixelFormat)
        
        
        //--------
        // 自分用
        //--------
        
        // 描画用センサ値配列をゼロ埋めクリア
        for _ in 0..._devideNumber {
            _array.append(0)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 描画バッファをクリア。drawRectの最初で呼ぶ
    func Clear() {
        glClearColor(0.0, 0.5, 1.0, 1.0)
        glClear(GLenum(GL_COLOR_BUFFER_BIT) | GLenum(GL_DEPTH_BUFFER_BIT));
        
        glViewport(0, 0, _width, _height)
        glMatrixMode(GLenum(GL_PROJECTION))
        glLoadIdentity()
        glOrtho(0.0, GLdouble(_width), 0.0, GLdouble(_height), -1.0, 1.0);
        glMatrixMode(GLenum(GL_MODELVIEW))
        glLoadIdentity()
    }
    
    // 描写のアップデートを司る関数。
    // NSOpenGLViewクラスには描写をアップデートするためのupdate()メソッドが用意されている (本プログラムではオーバーライドしていない) ためこれを呼ぶが、これを単純に呼ぶだけでは描写は更新されない。
    // その前にneedsDisplayをtrueにする必要がある．update()がコールされると，drawRect()が叩かれる
    func updateScene() {
        self.needsDisplay = true
        self.update()
    }
    
    /*===============================================================================================================================================================================================================*/
    // drawRectはNSView系に共通で、ロード時、windowのreshape時、update()がコールされた時に実行される。OpenGLの描写内容はここで記述する
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        
        // Drawing code here.
        
        // 描画バッファをクリア
        Clear()
        
        //blend for PointSmooth
        glBlendFunc(GLenum(GL_SRC_ALPHA), GLenum(GL_ONE_MINUS_SRC_ALPHA))
        //glBlendFunc(GLenum(GL_SRC_COLOR), GLenum(GL_ONE_MINUS_SRC_COLOR)) // こちらだと縞々がマシになる
        glEnable(GLenum(GL_BLEND))
        glEnable(GLenum(GL_POINT_SMOOTH))
        glEnable(GLenum(GL_LINE_SMOOTH)) // スムージングをキャンセルすると縞々が無くなるが，描画更新時に点や線がちらつく
        
        //glPointSize(4)
        
        // プロットのカラー設定
        glColor4f(0.0, 1.0, 0.5, 1.0)
        
        // 描画用センサ値配列のデータ更新．
        // 先頭を削除して末尾に新しい値を入れる(シフトしている)
        if _valueString != "" {
            _array.remove(at: 0)
            _array.append(Int(_valueString)!)
        }
        
        
        //------
        // 描画
        //------
        
        // 1bin分の横幅を求める
        let devidedWidth : GLfloat = GLfloat(frame.size.width)/GLfloat(_devideNumber)
        // bin数分だけ繰り返し、描画用センサ値配列の要素を使って描画
        for i in 0..<_devideNumber {
            // x軸の描画位置を求める
            let x : GLfloat = devidedWidth*GLfloat(i)
            // GL_LINESの線幅設定
            glLineWidth(devidedWidth)
            
            // 実際に描画する
            // mbedからの信号値(uint)の最大値で画面高さを割って、それをセンサ値に掛けてやることで、画面の高さに合わせて最大・最小値の幅を正規化 (描画用に行っているだけで実際のセンサ値は上書き変更しない)
            glBegin(GLenum(GL_LINES)) // 1本のラインで1つのbinを描画する
            glVertex2f(x, 0)
            glVertex2f(x, GLfloat(_array[i])*GLfloat(frame.size.height/65535))
            glEnd()
        }
        
        glDisable(GLenum(GL_BLEND))
        
        //flush
        glFlush()
    }
    
    
    /*===============================================================================================================================================================================================================*/
    //windowがreshapeされた時に呼ばれる。windowサイズが変更された時のため、glViewportをwindowサイズに合わせる
    override func reshape() {
        glViewport(0, 0, self._width, self._height)
        glMatrixMode(GLenum(GL_PROJECTION))
        glLoadIdentity()
        glOrtho(0.0, GLdouble(_width), 0.0, GLdouble(_height), -1.0, 1.0);
        glMatrixMode(GLenum(GL_MODELVIEW))
        glLoadIdentity()
    }
}

