//
//  DirectionalPadViewController.swift
//  capCalc
//
//  Created by mtfrctl on 2016/01/10.
//  Copyright © 2016年 鶴田 真也. All rights reserved.
//

import Cocoa
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l <= r
    default:
        return !(rhs < lhs)
    }
}


class DirectionalPadViewController: NSViewController {
    
    @IBOutlet weak var padUp : NSButton?
    @IBOutlet weak var padDown : NSButton?
    @IBOutlet weak var padLeft : NSButton?
    @IBOutlet weak var padRight : NSButton?
    
    fileprivate
    
    // 各パッドを全て保持する配列
    var pads : [NSButton] = []
    
    // オート閾値登録における物理キーのホールド状態とリリース指示の表示ラベル
    @IBOutlet weak var thresholdingStateLabel : NSTextField?
    
    // リアルタイムなセンサ値をSensorモデルクラスから取ってきて保持する用
    var sensorValue : Int = 0
    // 閾値登録時に使用するトラックパッドのクリックによる容量増加の補正値
    var regulateValue : Int = 0 // 3000
    
    // 物理キーが押されたと自動的に判断するために必要なセンサ値の変動幅
    var fluctuationForAutoHolding : Int = 4000 // 10000
    // 自動閾値登録の段階数カウンタ (キー数に相当)
    var autoThresholdingStepCounter : Int = 4 - 1
    // 自動閾値登録の繰り返し数数カウンタ
    let autoThresholdingRepeatNumber : Int = 4000 // 100000
    var autoThresholdingRepeatCounter : Int = 0
    // 自動閾値登録のスタート時ウェイトカウンタ
    let autoThresholdingStartWaitNumber : Int = 1000 // 20000
    var autoThresholdingStartWaitCounter : Int = 0
    
    // 一時的なセンサ値の上下限
    var sensorTemporaryMin : Int = 65535
    var sensorTemporaryMax : Int = 0
    // パディング (上下限ぴったりでは実際のタッチ時に厳しすぎる場合があるため余裕を持たせる)
    var sensorTemporaryPadding : Int = 100 // 700
    
    // 方向パッドのそれぞれの上下閾値を全て保持する配列
    var thresholds : [[String: Int]] = [[String: Int]](repeating: ["low": 0, "hi": 0], count: 4)
    
    
    /*===============================================================================================================================================================================================================*/
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
        print("DirectionalPadView startup")
        //Sensor.sharedInstance.addObserver(self, forKeyPath: "_sensorValue", options: .New, context: nil)
        
        // ソフトウェアキーを全て配列に保持
        pads = [padUp!, padDown!, padLeft!, padRight!]
        
        // 自動閾値登録の繰り返し数数カウンタを初期化
        autoThresholdingRepeatCounter = autoThresholdingRepeatNumber
        // 自動閾値登録のスタート時ウェイトカウンタを初期化
        autoThresholdingStartWaitCounter = autoThresholdingStartWaitNumber
    }
    
    override func viewWillAppear() {
        print("DirectionalPadView appear")
        Sensor.sharedInstance.addObserver(self, forKeyPath: "sensorValue", options: .new, context: nil)
    }
    
    override func viewDidDisappear() {
        Sensor.sharedInstance.removeObserver(self, forKeyPath: "sensorValue")
    }
    
    
    /*===============================================================================================================================================================================================================*/
    
    // 監視しているキー値が変更されるたび実行
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        // センサ値が更新されたら
        if keyPath == "sensorValue" {
            // センサ値を取得し，本クラスのインスタンス変数に保存
            sensorValue = change![NSKeyValueChangeKey.newKey] as! Int + regulateValue // トラックパッドにタッチしている分の調整
            
            // 閾値を更新するか(簡易学習)，キーをハイライトするか(実行)
            switch Enums.sharedInstance.directionalPadProcessingState {
            case .directionalPadProcessingStateAutoThresholding:
                autoUpdateThreshold()
                break
            case .directionalPadProcessingStateKey:
                self.highlightKey()
                break
            }
        }
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // オート閾値設定 (物理キーを押しながら登録)
    // Execute auto Thr. ボタンを押してから，Enter, 9, 8, ..., 1 の順に物理キーを押すことで，自動的に閾値を登録する
    
    // オート閾値登録
    func autoUpdateThreshold() {
        //print(sensorValue)
        //print(Sensor.sharedInstance.sensorValueBuffer[0] - sensorValue)
        
        // 物理キーを押し始めたとき (センサ値の変動の大きさをもとに推定する)
        if (Sensor.sharedInstance.sensorValueBuffer[0] - sensorValue) > fluctuationForAutoHolding {
            // 押す瞬間の1回だけを検知する
            if Enums.sharedInstance.directionalPadPhysicalHoldingState == .directionalPadPhysicalHoldingStateUnholding {
                // ホールディング状況ラベルを更新
                thresholdingStateLabel?.stringValue = "Thresholding."
            }
            Enums.sharedInstance.directionalPadPhysicalHoldingState = .directionalPadPhysicalHoldingStateHolding
            if autoThresholdingStartWaitCounter < 0 {
                //sensorTemporaryMin = sensorValue
                //sensorTemporaryMax = sensorValue // こっちもっと遅くの値をとらないとだめ．押し始めいきなりだとまだ坂の最中なので，落ち着く前の大きめの値が登録されてしまう
            }
        }
            // 物理キーを離したとき (センサ値の変動の大きさをもとに推定する)
        else if (sensorValue - Sensor.sharedInstance.sensorValueBuffer[0]) > fluctuationForAutoHolding {
            // 離す瞬間の1回だけを検知する
            if Enums.sharedInstance.directionalPadPhysicalHoldingState == .directionalPadPhysicalHoldingStateHolding {
                // ホールディング状況ラベルを更新
                thresholdingStateLabel?.stringValue = "Not thresholding."
                // 物理キーを1回離すたびに，ステップを1つデクリメント
                autoThresholdingStepCounter -= 1
                // 自動閾値登録の繰り返し回数をリセット
                autoThresholdingRepeatCounter = autoThresholdingRepeatNumber
                // 自動閾値登録のスタート時ウェイトカウンタをリセット
                autoThresholdingStartWaitCounter = autoThresholdingStartWaitNumber
                // 上下閾値を初期化
                sensorTemporaryMin = 65535
                sensorTemporaryMax = 0
            }
            // アンホールディングステートに
            Enums.sharedInstance.directionalPadPhysicalHoldingState = .directionalPadPhysicalHoldingStateUnholding
            // 全てのステップを終えたら，ステートを通常モードに戻す
            if autoThresholdingStepCounter < 0 {
                Enums.sharedInstance.directionalPadProcessingState = .directionalPadProcessingStateKey
            }
        }
            // 物理キーを押している間と，物理キーを押していない間
        else {
            switch Enums.sharedInstance.directionalPadPhysicalHoldingState {
            // 物理キーを押している間
            case .directionalPadPhysicalHoldingStateHolding:
                // 自動閾値登録の繰返し回数以内なら閾値登録を実行 (指をキーから離すときの値変動対策)
                if autoThresholdingRepeatCounter > 0 {
                    if autoThresholdingStartWaitCounter < 0 {
                        //print("holding")
                        //print("Thresholding key:", autoThresholdingStepCounter)
                        
                        // 上下閾値を更新
                        if sensorValue < sensorTemporaryMin {
                            sensorTemporaryMin = sensorValue
                        }
                        if sensorValue > sensorTemporaryMax {
                            sensorTemporaryMax = sensorValue
                        }
                        
                        // 上下閾値を標準出力
                        //print("Min", sensorTemporaryMin)
                        //print("Max", sensorTemporaryMax)
                        
                        // 上下閾値を設定
                        thresholds[autoThresholdingStepCounter]["low"] = sensorTemporaryMin - sensorTemporaryPadding
                        thresholds[autoThresholdingStepCounter]["hi"] = sensorTemporaryMax + sensorTemporaryPadding
                        
                        // 自動閾値登録の繰返し回数カウンタをデクリメント
                        autoThresholdingRepeatCounter -= 1
                    }
                    
                    // 自動閾値登録のスタート時ウェイトカウンタをデクリメント
                    autoThresholdingStartWaitCounter -= 1
                } else {
                    // ホールディング状況ラベルを更新
                    thresholdingStateLabel?.stringValue = "Thresholding finished."
                }
                break
            // 物理キーを押していない間
            case .directionalPadPhysicalHoldingStateUnholding:
                //print("Unholding")
                break
            }
        }
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // キーをハイライト
    // 現在のセンサ値を各キーの上下閾値と比較する
    func highlightKey() {
        if thresholds[3]["low"] <= sensorValue && sensorValue < thresholds[3]["hi"] {
            padUp?.state = NSOnState // ON
            padDown?.state = NSOffState
            padLeft?.state = NSOffState
            padRight?.state = NSOffState
        }
        else if thresholds[2]["low"] <= sensorValue && sensorValue < thresholds[2]["hi"] {
            padUp?.state = NSOffState
            padDown?.state = NSOffState
            padLeft?.state = NSOnState // ON
            padRight?.state = NSOffState
        }
        else if thresholds[1]["low"] <= sensorValue && sensorValue < thresholds[1]["hi"] {
            padUp?.state = NSOffState
            padDown?.state = NSOnState // ON
            padLeft?.state = NSOffState
            padRight?.state = NSOffState
        }
        else if thresholds[0]["low"] <= sensorValue && sensorValue < thresholds[0]["hi"] {
            padUp?.state = NSOffState
            padDown?.state = NSOffState
            padLeft?.state = NSOffState
            padRight?.state = NSOnState // ON
        }
        else if  55000 < sensorValue {
            padUp?.state = NSOffState
            padDown?.state = NSOffState
            padLeft?.state = NSOffState
            padRight?.state = NSOffState
        }
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // アクションメソッド群
    
    // オート閾値設定の開始ボタンがクリックされたとき
    @IBAction func autoThresholdButtonClicked(_ sender : AnyObject) {
        Enums.sharedInstance.directionalPadProcessingState = .directionalPadProcessingStateAutoThresholding
        autoThresholdingStepCounter = 4 - 1
    }
    
    @IBAction func padClicked(_ sender : AnyObject) {
        print(String(format: "pad %d clicked", sender.tag))
    }
}

