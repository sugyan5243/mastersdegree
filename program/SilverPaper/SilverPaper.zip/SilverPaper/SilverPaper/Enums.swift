//
//  Enums.swift
//  SilverPaper
//
//  Created by sugyan5243 on 2017/10/29.
//  Copyright © 2017年 sugyan5243. All rights reserved.
//
// 各種のステートやフェイズを表現するenumを定義するシングルトンクラス．鶴田のプログラムをそのまま用いている
//  各種とは，テンキー・方向パッド・スワイプジェスチャのこと

import Cocoa

class Enums: NSObject {
    // 1.2以降はこれでよい
    static let sharedInstance = Enums()
    
    override init() {
        super.init()
        print("Sensor model initialized!!")
    }
    
    
    /*===============================================================================================================================================================================================================*/
    // テンキー
    
    // 動作モードの種別
    enum TenKeyProcessingState {
        case tenKeyProcessingStateManualThresholding
        case tenKeyProcessingStateAutoThresholding
        case tenKeyProcessingStateKey
    }
    // 動作モードを保持
    var tenKeyProcessingState : TenKeyProcessingState = .tenKeyProcessingStateKey
    
    // 物理テンキーが押されているかの状態
    enum TenKeyPhysicalHoldingState {
        case tenKeyPhysicalHoldingStateHolding
        case tenKeyPhysicalHoldingStateUnholding
    }
    var tenKeyPhysicalHoldingState : TenKeyPhysicalHoldingState = .tenKeyPhysicalHoldingStateUnholding
    
    /*===============================================================================================================================================================================================================*/
    // 方向パッド
    
    // 動作モードの種別
    enum DirectionalPadProcessingState {
        case directionalPadProcessingStateAutoThresholding
        case directionalPadProcessingStateKey
    }
    // 動作モードを保持
    var directionalPadProcessingState : DirectionalPadProcessingState = .directionalPadProcessingStateKey
    
    // 物理テンキーが押されているかの状態
    enum DirectionalPadPhysicalHoldingState {
        case directionalPadPhysicalHoldingStateHolding
        case directionalPadPhysicalHoldingStateUnholding
    }
    var directionalPadPhysicalHoldingState : DirectionalPadPhysicalHoldingState = .directionalPadPhysicalHoldingStateUnholding
    
    
    /*===============================================================================================================================================================================================================*/
    // スワイプジェスチャ
    
    // 電極タッチ中か否か (閾値を下回っている間か否か)
    enum SwipeGestureTouchingState {
        case swipeGestureTouchingStateTouching
        case swipeGestureTouchingStateNotTouching
    }
    // 電極タッチ中かを保持
    var swipeGestureTouchingState : SwipeGestureTouchingState = .swipeGestureTouchingStateNotTouching
    
    // ジェスチャ中か否か
    enum SwipeGestureGesturingState {
        case swipeGestureGesturingStateGesturing
        case swipeGestureGesturingStateNotGesturing
    }
    // ジェスチャ中か否かを保持
    var swipeGestureGesturingState : SwipeGestureGesturingState = .swipeGestureGesturingStateNotGesturing
}

