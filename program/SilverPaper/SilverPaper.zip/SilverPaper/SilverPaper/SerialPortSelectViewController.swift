//
//  SerialPortSelectViewController.swift
//  capCalc
//
//  Created by mtfrctl on 2015/10/20.
//  Copyright © 2015年 鶴田 真也. All rights reserved.
//

import Cocoa
import ORSSerial

class SerialPortSelectViewController: NSViewController {
    
    // IBOutletはvarにする必要がある．
    // また，Obj-Cのときと同様，weak指定する．
    @IBOutlet weak var _okButton : NSButton?
    @IBOutlet weak var _cancelButton : NSButton?
    @IBOutlet weak var _popUpButton : NSPopUpButton?
    
    var _serialPortNames : [String] = []
    dynamic var _selectedSerialPortTag : NSNumber? // IFBにおいて、NSPopUpButtonで選択されたitemのタグがこれにバインディングされている
    
    /*===============================================================================================================================================================================================================*/
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
        
    }
    
    override func viewWillAppear() {
        // セグエ元からrepresentedObjectを介してシリアルポート名の一覧を受け取る
        _serialPortNames = representedObject as! [String]
        
        // popUpButtonのアイテムを初期化してタグをセット
        _popUpButton?.removeAllItems()
        var i = 0
        for serialportName : String in _serialPortNames {
            _popUpButton?.addItem(withTitle: serialportName)
            _popUpButton?.item(at: i)?.tag = i
            i += 1
        }
        // 初期値を設定
        _selectedSerialPortTag = 0
    }
    
    /*===============================================================================================================================================================================================================*/
    // IBActionは必ずAnyObject型(Obj-Cでのid型的な)引数をとる必要がある
    @IBAction func okButtonClicked(_ sender : AnyObject) {
        dismissViewController(self)
    }
    @IBAction func cancelButtonClicked(_ sender : AnyObject) {
        dismissViewController(self)
        //exit(0) // アプリを終了
    }
}

